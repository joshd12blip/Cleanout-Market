# Cleanout Market (Free, No-Cost MVP)

This is a **$0 beginner-friendly** marketplace prototype. It lets you:
- Add listings (title, price, condition, location, photo URL).
- Filter/search items.
- Add items to a cart.
- Click **Cart** to generate an **email draft** with your order (no paid services).

> You can deploy this free on **Vercel** or **GitHub Pages**.

## Quick Start (on your computer)
1. Install Node.js (LTS) from nodejs.org
2. Open a terminal in this folder and run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the URL printed in the terminal.

## Deploy to Vercel (free)
1. Create a free account at https://vercel.com and install the Vercel CLI (optional).
2. Push this folder to a new GitHub repo (or import the folder in Vercel dashboard).
3. In Vercel, “New Project” → import the repo → framework: **Vite** → deploy.
4. You’ll get a live URL like `https://yourname.vercel.app` to share.

## Deploy to GitHub Pages (free)
1. Create a GitHub repo and upload these files.
2. Add this to **package.json** (already set up for Vite builds):
   - Use: `npm run build`
   - Then publish the `dist/` folder to Pages (via GitHub Pages settings or gh-pages action).
3. Enable **Pages** in the repo settings (branch: `gh-pages` or `/dist`).

## Customise
- Change commission in `src/App.jsx` → `COMMISSION_RATE`.
- Edit seed items in `src/App.jsx` (`seedItems` array).
- Change email address in `src/App.jsx` inside `mailtoOrder()` (`to` variable).

## Upgrade Path (still $0)
- Replace mailto with **Resend** or **EmailJS** free tiers to send emails without opening a user’s email client.
- Store listings in a free-tier database (Supabase) instead of memory.
- Add admin login (Supabase Auth) to approve listings and attach consent files.
- When you’re ready to accept real payments, use Stripe (free to set up; transaction fees apply).

## NDIS-aligned policies (draft)
- **Consent & Ownership:** obtain participant/guardian written consent before listing.
- **Prohibited:** no medical devices/consumables, hazardous goods, perishables, child seats, recalled items.
- **Hygiene & Testing:** wipe/sanitise; note any electrical testing.
- **Returns:** faults within 7 days (no change of mind).
- **Privacy:** photos never reveal occupants; strip metadata.

